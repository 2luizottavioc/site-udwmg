# Atividade prática - Visualização Fotos/Caixa comentários

Para criar testar essa aplicação rodando em seu ambiente local, certifique-se de instalar o docker (com docker compose) e executar o seguinte comando:
```docker
docker compose up -d
```
Se tudo der certo, sua aplicação estará disponível no endereço ```http://localhost:8080/```